<?php



include $this->template('index');
?>