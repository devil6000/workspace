<?php
/**
 * nearby_stores模块定义
 *
 * @author EdisonLiu_
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class jujiwuliuModule extends WeModule {



}