<?php
/**
 * nearby_stores模块处理程序
 *
 * @author EdisonLiu_
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class jujiwuliuModuleProcessor extends WeModuleProcessor {
	public function respond() {
		$content = $this->message['content'];
		//这里定义此模块进行消息处理时的具体过程, 请查看巨吉物流文档来编写你的代码
	}
}