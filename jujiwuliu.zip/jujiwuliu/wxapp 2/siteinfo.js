var debug=0;

var siteinfo = { "m": 'jujiwuliu', "uniacid": "3", "acid": "3", "version": "1.0", "siteroot": "https://app.jujiwuliu.com/app/index.php", 'attachurl': 'https://app.jujiwuliu.com/attachment/', 'SocketUrl': 'wss://app.jujiwuliu.com/jujiwuliu', 'debug_siteroot': "http://app.jujiwuliu.com/app/index.php", 'debug_SocketUrl': 'ws://app.jujiwuliu.com/jujiwuliu', 'debug': debug}

module.exports = siteinfo