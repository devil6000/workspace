var e = getApp();

Page({
  data: {
    lng: 120.81303,
    lat: 27.93252,
        scale: 13,
        realname: "刘",
        address: "温州市龙湾区蓝江软件园",
        mobile:15555555555,
        subkey:"OHDBZ-DL4CQ-7O55M-G3DSI-NSXX3-AZF6F",
        markers: [{
          iconPath: "../../../resource/images/location.png",
          id: 0,
          longitude:0,
          latitude: 0,
            width: 30,
            height: 30,
            label: {
                content: "客户地址",
                color: "#666666",
                fontSize: 12,
                borderRadius: 10,
                bgColor: "#ffffff",
                padding: 5,
                display: "ALWAYS",
                textAlign: "center",
                x: -20,
                y: -60
            }
        } ],

    },
    
    get_list: function() {},
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
    onLoad: function(t) {
        var that = this;

      var markers=that.data.markers;
      markers[0].longitude = that.data.lng;
      markers[0].latitude=that.data.lat;
that.setData({
  markers: markers
})
      console.log(that.markers)
    },
    open_location: function (e) {
      var that = this;
      wx.openLocation({
        longitude : that.data.lng,
        latitude: that.data.lat,
        scale: 18,
        name: '详细地址',
        address: that.data.address
      })
  },
});