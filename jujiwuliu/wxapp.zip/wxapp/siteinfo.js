var debug=0;

var siteinfo = { "m": 'jujiwuliu', "uniacid": "3", "acid": "3", "version": "1.0", "siteroot": "https://www.jujiwuliu.com/app/index.php", 'attachurl': 'https://www.jujiwuliu.com/attachment/', 'SocketUrl': 'wss://www.jujiwuliu.com/jujiwuliu', 'debug_siteroot': "http://www.banyungon.com/app/index.php", 'debug_SocketUrl': 'ws://www.banyungon.com/jujiwuliu', 'debug': debug}

module.exports = siteinfo